"""TAP&EAT Telegram food ordering bot. Python 3.11+."""
import logging
import os
import secrets
import sqlite3
import threading
from datetime import datetime, timezone
from html import escape

from flask import Flask, jsonify
from telegram import InlineKeyboardButton as Button, InlineKeyboardMarkup as Markup, Update
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes, MessageHandler, filters

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
log = logging.getLogger('tap-eat')
TOKEN = os.getenv('BOT_TOKEN', '').strip()
ADMIN_ID = int(os.getenv('ADMIN_ID', '0'))
DB = os.getenv('DATABASE_PATH', 'tap_eat.db')
PORT = int(os.getenv('PORT', '8080'))
app = Flask(__name__)


def connect():
    db = sqlite3.connect(DB, timeout=20)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA busy_timeout=20000')
    return db


def initialize():
    with connect() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, username TEXT,
          full_name TEXT, phone TEXT, dorm TEXT, block TEXT, room TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
        db.execute('''CREATE TABLE IF NOT EXISTS restaurants (id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT UNIQUE NOT NULL, is_active INTEGER DEFAULT 1)''')
        db.execute('''CREATE TABLE IF NOT EXISTS menu_items (id INTEGER PRIMARY KEY AUTOINCREMENT,
          restaurant_id INTEGER NOT NULL, name TEXT NOT NULL, price REAL NOT NULL,
          is_available INTEGER DEFAULT 1)''')
        db.execute('''CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY AUTOINCREMENT,
          order_code TEXT UNIQUE NOT NULL, user_id INTEGER NOT NULL, restaurant_name TEXT,
          food_name TEXT, quantity INTEGER, total_price REAL, customer_name TEXT, phone TEXT,
          dorm TEXT, block TEXT, room TEXT, status TEXT DEFAULT 'pending',
          created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
        if not db.execute('SELECT 1 FROM restaurants LIMIT 1').fetchone():
            samples = {
                '🍕 Pizza Palace': [('Margherita Pizza', 12.99), ('Pepperoni Pizza', 14.99), ('Veggie Pizza', 13.99)],
                '🍔 Burger Joint': [('Cheeseburger', 8.99), ('Chicken Burger', 9.99), ('Double Burger', 11.99)],
                '☕ Coffee Corner': [('Cappuccino', 3.99), ('Latte', 4.49), ('Mocha', 4.99)],
                '🌯 Wrap Station': [('Chicken Wrap', 7.99), ('Veggie Wrap', 6.99)],
            }
            for name, items in samples.items():
                cur = db.execute('INSERT INTO restaurants(name) VALUES (?)', (name,))
                db.executemany('INSERT INTO menu_items(restaurant_id,name,price) VALUES (?,?,?)',
                               [(cur.lastrowid, food, price) for food, price in items])


def keyboard(rows):
    return Markup([[Button(label, callback_data=action) for label, action in row] for row in rows])


def main_keyboard(admin=False):
    rows = [[('🍽️ Order Food', 'restaurants')], [('📋 My Orders', 'my_orders')],
            [('⚙️ My Info', 'my_info')], [('ℹ️ Help', 'help')]]
    if admin:
        rows.append([('👑 Admin Panel', 'admin')])
    return keyboard(rows)


def admin_keyboard():
    return keyboard([[('📦 Pending Orders', 'pending')], [('📈 Stats', 'stats')], [('🏠 Main Menu', 'home')]])


def is_admin(user_id):
    return ADMIN_ID > 0 and user_id == ADMIN_ID


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    with connect() as db:
        db.execute('INSERT OR IGNORE INTO users(user_id,username,full_name) VALUES (?,?,?)',
                   (u.id, u.username or '', u.full_name))
    await update.message.reply_text(
        f'🎓 Welcome to TAP&EAT, {u.first_name}!\n\n🍔 Campus food delivery\n'
        '1. Choose a restaurant\n2. Select food and quantity\n3. Enter delivery details\n'
        '4. Confirm your order\n5. Track your order', reply_markup=main_keyboard(is_admin(u.id)))


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text('🍽️ TAP&EAT Help\nUse /start to order food.\n'
                                    'Your orders appear under My Orders. Contact your campus admin for support.')


async def edit(query, message, markup=None, parse_mode=None):
    await query.edit_message_text(message, reply_markup=markup, parse_mode=parse_mode)


async def show_restaurants(query):
    with connect() as db:
        restaurants = db.execute('SELECT id,name FROM restaurants WHERE is_active=1').fetchall()
    rows = [[(r['name'], f'rest:{r["id"]}')] for r in restaurants]
    rows.append([('🔙 Back', 'home')])
    await edit(query, '🏪 Choose a restaurant:' if restaurants else 'No restaurants available.', keyboard(rows))


async def show_menu(query, restaurant_id):
    with connect() as db:
        restaurant = db.execute('SELECT name FROM restaurants WHERE id=? AND is_active=1', (restaurant_id,)).fetchone()
        items = db.execute('SELECT id,name,price FROM menu_items WHERE restaurant_id=? AND is_available=1',
                           (restaurant_id,)).fetchall()
    if not restaurant:
        await query.answer('Restaurant unavailable', show_alert=True)
        return
    rows = [[(f'{item["name"]} - ${item["price"]:.2f}', f'item:{item["id"]}')] for item in items]
    rows.append([('🔙 Restaurants', 'restaurants')])
    await edit(query, f'🏪 {restaurant["name"]}\nChoose an item:' if items else 'No items available.', keyboard(rows))


async def show_item(query, item_id):
    with connect() as db:
        item = db.execute('SELECT * FROM menu_items WHERE id=? AND is_available=1', (item_id,)).fetchone()
    if not item:
        await query.answer('Item unavailable', show_alert=True)
        return
    rows = [[(str(i), f'qty:{item_id}:{i}') for i in range(1, 4)],
            [(str(i), f'qty:{item_id}:{i}') for i in range(4, 6)],
            [('🔙 Menu', f'rest:{item["restaurant_id"]}')]]
    await edit(query, f'🍽️ {item["name"]}\n💰 ${item["price"]:.2f}\nChoose quantity:', keyboard(rows))


def user_record(user_id):
    with connect() as db:
        return db.execute('SELECT * FROM users WHERE user_id=?', (user_id,)).fetchone()


def order_summary(data, user):
    return (f'✅ ORDER SUMMARY\n\n🏪 {data["restaurant_name"]}\n🍽️ {data["item_name"]}\n'
            f'🔢 Quantity: {data["quantity"]}\n💰 Total: ${data["total"]:.2f}\n\n'
            f'👤 {user["full_name"]}\n📞 {user["phone"]}\n'
            f'📍 Dorm: {user["dorm"]}, Block: {user["block"]}, Room: {user["room"] or "N/A"}\n\n'
            'Type 1 to confirm or 2 to cancel.')


async def choose_quantity(query, context, item_id, quantity):
    if quantity not in range(1, 6):
        return
    with connect() as db:
        item = db.execute('''SELECT m.name,m.price,r.name AS restaurant_name FROM menu_items m
           JOIN restaurants r ON m.restaurant_id=r.id WHERE m.id=? AND m.is_available=1 AND r.is_active=1''',
                          (item_id,)).fetchone()
    if not item:
        await query.answer('Item unavailable', show_alert=True)
        return
    context.user_data.clear()
    context.user_data['order'] = dict(item_name=item['name'], price=item['price'],
        restaurant_name=item['restaurant_name'], quantity=quantity, total=round(item['price'] * quantity, 2))
    user = user_record(query.from_user.id)
    if user and all(user[k] for k in ('phone', 'full_name', 'dorm', 'block')):
        context.user_data['state'] = 'confirm'
        await edit(query, order_summary(context.user_data['order'], user))
    else:
        context.user_data['state'] = 'phone'
        await edit(query, '📝 Enter your phone number (at least 10 digits):')


async def show_orders(query):
    with connect() as db:
        orders = db.execute('''SELECT order_code,food_name,quantity,total_price,status,created_at
             FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 10''', (query.from_user.id,)).fetchall()
    lines = [f'📦 {r["order_code"]}: {r["food_name"]} ×{r["quantity"]}\n'
             f'${r["total_price"]:.2f} — {r["status"]}' for r in orders]
    await edit(query, '📋 Your Orders\n\n' + ('\n\n'.join(lines) if lines else 'No orders yet.'),
               main_keyboard(is_admin(query.from_user.id)))


async def show_info(query):
    user = user_record(query.from_user.id)
    if not user or not user['phone']:
        msg = 'No delivery details saved. Place an order to enter them.'
    else:
        msg = (f'👤 {user["full_name"]}\n📞 {user["phone"]}\n'
               f'🏢 Dorm: {user["dorm"]}\n🏠 Block: {user["block"]}\n🚪 Room: {user["room"] or "N/A"}')
    await edit(query, msg, main_keyboard(is_admin(query.from_user.id)))


def format_admin_order(o):
    return (f'🚨 <b>ORDER #{o["id"]}</b>\nCode: {escape(o["order_code"])}\n'
            f'🏪 {escape(o["restaurant_name"] or "")}\n🍽️ {escape(o["food_name"] or "")} ×{o["quantity"]}\n'
            f'💰 ${o["total_price"]:.2f}\n👤 {escape(o["customer_name"] or "")}\n'
            f'📞 {escape(o["phone"] or "")}\n📍 Dorm: {escape(o["dorm"] or "")}, '
            f'Block: {escape(o["block"] or "")}, Room: {escape(o["room"] or "")}\n'
            f'Status: {escape(o["status"])}')


def actions(order_id):
    return keyboard([[('✅ Accept', f'status:{order_id}:accepted'), ('❌ Reject', f'status:{order_id}:rejected')],
                     [('🚚 Delivered', f'status:{order_id}:delivered')], [('🔙 Orders', 'pending')]])


async def pending(query):
    with connect() as db:
        order = db.execute("SELECT * FROM orders WHERE status='pending' ORDER BY id DESC LIMIT 1").fetchone()
    if not order:
        await edit(query, '📭 No pending orders.', admin_keyboard())
    else:
        await edit(query, format_admin_order(order), actions(order['id']), 'HTML')


async def stats(query):
    with connect() as db:
        users = db.execute('SELECT COUNT(*) FROM users').fetchone()[0]
        orders = db.execute('SELECT COUNT(*) FROM orders').fetchone()[0]
        pending_count = db.execute("SELECT COUNT(*) FROM orders WHERE status='pending'").fetchone()[0]
        delivered = db.execute("SELECT COUNT(*) FROM orders WHERE status='delivered'").fetchone()[0]
        revenue = db.execute("SELECT COALESCE(SUM(total_price),0) FROM orders WHERE status='delivered'").fetchone()[0]
    await edit(query, f'📈 TAP&EAT Stats\n👥 Users: {users}\n📦 Orders: {orders}\n'
               f'⏳ Pending: {pending_count}\n🚚 Delivered: {delivered}\n💰 Revenue: ${revenue:.2f}', admin_keyboard())


async def change_status(query, context, order_id, new_status):
    if new_status not in ('accepted', 'rejected', 'delivered'):
        return
    with connect() as db:
        order = db.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()
        if not order:
            await query.answer('Order not found', show_alert=True)
            return
        if order['status'] == new_status:
            await query.answer('Already updated')
            return
        db.execute('UPDATE orders SET status=? WHERE id=?', (new_status, order_id))
    try:
        await context.bot.send_message(order['user_id'], f'📢 Order {order["order_code"]} is now {new_status}.')
    except Exception:
        log.exception('Customer notification failed')
    await edit(query, f'✅ Order #{order_id}: {new_status}', admin_keyboard())


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    data = q.data or ''
    uid = q.from_user.id
    try:
        if data == 'home':
            context.user_data.clear()
            await edit(q, '🏠 TAP&EAT Main Menu', main_keyboard(is_admin(uid)))
        elif data == 'restaurants':
            await show_restaurants(q)
        elif data.startswith('rest:'):
            await show_menu(q, int(data.split(':')[1]))
        elif data.startswith('item:'):
            await show_item(q, int(data.split(':')[1]))
        elif data.startswith('qty:'):
            _, item, quantity = data.split(':')
            await choose_quantity(q, context, int(item), int(quantity))
        elif data == 'my_orders':
            await show_orders(q)
        elif data == 'my_info':
            await show_info(q)
        elif data == 'help':
            await edit(q, 'ℹ️ Choose Order Food to begin. Contact the admin for support.', main_keyboard(is_admin(uid)))
        elif data in ('admin', 'pending', 'stats') or data.startswith('status:'):
            if not is_admin(uid):
                await q.answer('Admin only', show_alert=True)
                return
            if data == 'admin':
                await edit(q, '👑 Admin Panel', admin_keyboard())
            elif data == 'pending':
                await pending(q)
            elif data == 'stats':
                await stats(q)
            else:
                _, oid, status = data.split(':')
                await change_status(q, context, int(oid), status)
    except Exception:
        log.exception('Callback failed')
        try:
            await q.message.reply_text('❌ Something went wrong. Send /start to try again.')
        except Exception:
            log.exception('Failed to report callback error')


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    state = context.user_data.get('state')
    text = (update.message.text or '').strip()
    uid = update.effective_user.id
    if not state:
        await update.message.reply_text('Choose an option:', reply_markup=main_keyboard(is_admin(uid)))
        return
    if state == 'confirm':
        if text == '2':
            context.user_data.clear()
            await update.message.reply_text('❌ Order cancelled.', reply_markup=main_keyboard(is_admin(uid)))
            return
        if text != '1':
            await update.message.reply_text('Type 1 to confirm or 2 to cancel.')
            return
        data = context.user_data.get('order')
        user = user_record(uid)
        if not data or not user or not user['phone']:
            context.user_data.clear()
            await update.message.reply_text('Order details missing. Send /start to try again.')
            return
        code = 'TAP' + secrets.token_hex(4).upper()
        with connect() as db:
            cur = db.execute('''INSERT INTO orders(order_code,user_id,restaurant_name,food_name,quantity,
                 total_price,customer_name,phone,dorm,block,room) VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
                 (code, uid, data['restaurant_name'], data['item_name'], data['quantity'], data['total'],
                  user['full_name'], user['phone'], user['dorm'], user['block'], user['room']))
            order_id = cur.lastrowid
            order = db.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()
        context.user_data.clear()
        await update.message.reply_text(f'✅ Order placed!\n📦 Code: {code}\n💰 ${data["total"]:.2f}\n'
                                        '⏳ Status: Pending', reply_markup=main_keyboard(is_admin(uid)))
        if ADMIN_ID:
            try:
                await context.bot.send_message(ADMIN_ID, format_admin_order(order),
                                               reply_markup=actions(order_id), parse_mode='HTML')
            except Exception:
                log.exception('Admin notification failed')
        return
    if state == 'phone':
        digits = text.replace('+', '').replace(' ', '').replace('-', '')
        if not digits.isdigit() or len(digits) < 10 or len(digits) > 15:
            await update.message.reply_text('Enter a valid phone number (10–15 digits).')
            return
        context.user_data['phone'] = text
        context.user_data['state'] = 'name'
        prompt = '👤 Enter your full name:'
    elif state == 'name':
        if len(text) < 2 or len(text) > 100:
            await update.message.reply_text('Enter a name between 2 and 100 characters.')
            return
        context.user_data['name'] = text
        context.user_data['state'] = 'dorm'
        prompt = '🏢 Enter your dorm:'
    elif state == 'dorm':
        if not 1 <= len(text) <= 100:
            await update.message.reply_text('Enter a dorm name (up to 100 characters).')
            return
        context.user_data['dorm'] = text
        context.user_data['state'] = 'block'
        prompt = '🏠 Enter your block:'
    elif state == 'block':
        if not 1 <= len(text) <= 100:
            await update.message.reply_text('Enter a block name (up to 100 characters).')
            return
        context.user_data['block'] = text
        context.user_data['state'] = 'room'
        prompt = '🚪 Enter your room, or type skip:'
    elif state == 'room':
        if len(text) > 100:
            await update.message.reply_text('Room must be at most 100 characters.')
            return
        room = '' if text.lower() == 'skip' else text
        with connect() as db:
            db.execute('''INSERT INTO users(user_id,username,full_name,phone,dorm,block,room)
              VALUES(?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET full_name=excluded.full_name,
              phone=excluded.phone,dorm=excluded.dorm,block=excluded.block,room=excluded.room''',
              (uid, update.effective_user.username or '', context.user_data['name'],
               context.user_data['phone'], context.user_data['dorm'], context.user_data['block'], room))
        context.user_data['state'] = 'confirm'
        await update.message.reply_text(order_summary(context.user_data['order'], user_record(uid)))
        return
    else:
        context.user_data.clear()
        await update.message.reply_text('Please send /start to begin again.')
        return
    await update.message.reply_text(prompt)


@app.get('/')
def home():
    return jsonify(service='tap-eat-bot', status='online')


@app.get('/health')
def health():
    try:
        with connect() as db:
            db.execute('SELECT 1')
        return jsonify(status='healthy', time=datetime.now(timezone.utc).isoformat()), 200
    except sqlite3.Error:
        log.exception('Health check failed')
        return jsonify(status='unhealthy'), 503


def main():
    if not TOKEN:
        raise RuntimeError('BOT_TOKEN is missing. Set it in your host environment variables.')
    initialize()
    threading.Thread(target=lambda: app.run(host='0.0.0.0', port=PORT, use_reloader=False), daemon=True).start()
    bot = Application.builder().token(TOKEN).build()
    bot.add_handler(CommandHandler('start', start))
    bot.add_handler(CommandHandler('help', help_command))
    bot.add_handler(CallbackQueryHandler(button_handler))
    bot.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    log.info('Starting TAP&EAT polling')
    bot.run_polling(drop_pending_updates=True)


if __name__ == '__main__':
    main()
