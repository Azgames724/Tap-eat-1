# TAP&EAT Telegram Bot

## Setup
1. Revoke any previously exposed Telegram token in @BotFather and create a fresh token.
2. Add `BOT_TOKEN` (new token) and `ADMIN_ID` (your numeric Telegram user ID) as **hosting environment variables**. Do not commit tokens.
3. Install packages: `pip install -r requirements.txt`
4. Start: `python boot.py`
5. Check `GET /health` and send `/start` to your Telegram bot.

This bot uses Telegram long polling and a small Flask health endpoint. Only one instance should poll a given bot token at a time. The SQLite database is stored at `DATABASE_PATH` (default `tap_eat.db`). On ephemeral free hosts, data can disappear after restarts or redeployments; configure persistent storage if available.

The restaurant list is sample data, and prices are in USD until customized. Admin order management requires `ADMIN_ID`.
